#ifndef __GUPNP_ENUM_TYPES_H__
#define __GUPNP_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "gupnp-simple-igd.h" */
GType gupnp_simple_igd_error_get_type (void);
#define GUPNP_TYPE_SIMPLE_IGD_ERROR (gupnp_simple_igd_error_get_type())
G_END_DECLS

#endif /* __GUPNP_ENUM_TYPES_H__ */
